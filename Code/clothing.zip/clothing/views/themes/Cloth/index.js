/* eslint-disable prefer-arrow-callback, no-var, no-tabs */
$(document).ready(function (){
    // Add specific code to this theme here
});
